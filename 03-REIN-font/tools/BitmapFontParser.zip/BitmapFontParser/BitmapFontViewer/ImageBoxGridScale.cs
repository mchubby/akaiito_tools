﻿
namespace Cyotek.Windows.Forms
{
  public enum ImageBoxGridScale
  {
    Small,
    Medium,
    Large
  }
}
