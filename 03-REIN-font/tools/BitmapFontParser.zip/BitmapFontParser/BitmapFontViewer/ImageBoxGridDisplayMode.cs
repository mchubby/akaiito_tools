﻿
namespace Cyotek.Windows.Forms
{
  public enum ImageBoxGridDisplayMode
  {
    None,
    Client,
    Image
  }
}
