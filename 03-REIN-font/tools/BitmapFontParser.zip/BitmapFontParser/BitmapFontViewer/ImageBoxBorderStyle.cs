﻿
namespace Cyotek.Windows.Forms
{
  public enum ImageBoxBorderStyle
  {
    None,
    FixedSingle,
    FixedSingleDropShadow
  }
}
